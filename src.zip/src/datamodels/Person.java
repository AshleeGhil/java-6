package datamodels;

import exceptionhandlers.InvalidDataException;
import interfaces.IPerson;

import java.time.LocalDate;

public class Person implements IPerson {

    public String name;
    public String address;
    public java.time.LocalDate dateOfBirth;

    @Override
    public void setName(String p_name) throws InvalidDataException {
        if (p_name.length() == 0) {
            throw new InvalidDataException("No Name Specified");
        }
        this.name = p_name;
    }

    @Override
    public void setAddress(String p_address) throws InvalidDataException {
        if (p_address.length() == 0) {
            throw new InvalidDataException("No address specified");
        }
        address = p_address;
    }

    @Override
    public void setDateOfBirth(LocalDate p_dateOfBirth) throws InvalidDataException {
        if (p_dateOfBirth  == null) {
            throw new InvalidDataException("Date of birth not specified, setting to null.");
        }
        dateOfBirth = p_dateOfBirth;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getAddress() {
        return address;
    }

    @Override
    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }


   /* public String toString() {
        return "Person{" + "Name=" + name + ", Address=" + address + ", DateOfBirth=" + dateOfBirth + '}';
    } */
}
