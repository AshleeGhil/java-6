package datamodels;

import exceptionhandlers.InvalidDataException;

import java.util.ArrayList;
import java.util.Iterator;

public class Faculty extends Person {

    private java.time.LocalDate dateOfHire;
    private String status;
    private Double salary;
    private ArrayList<Course> listOfCourses = new ArrayList<Course>();

    public void setStatus(String p_status) throws InvalidDataException {
        if (p_status == null){
            p_status = "full-time";
        }
        if (p_status == ""){
            p_status = "full-time";
        }
        status = p_status;
    }

    public void setDateOfHire(java.time.LocalDate p_dateOfHire){

        dateOfHire = p_dateOfHire;

    }

    public void setSalary(double p_salary) throws InvalidDataException {
        if (p_salary < 0) {
            throw new InvalidDataException("Invalid salary, setting to $0.");
        }
        salary = p_salary;

    }

    public java.time.LocalDate getDateOfHire(){

        return dateOfHire;

    }

    public ArrayList<Course> getListOfCourses() {
        return listOfCourses;
    }

    public String getStatus(){

        return status;

    }

    public Double getSalary(){

        return salary;

    }

    public String toString() {
        String courses = "";
        Iterator iter = listOfCourses.iterator();
        while (iter.hasNext()) {
            courses += iter.next().toString() + ", ";
        }
        return "Faculty{" + "Name= " + name + ", Address= " + address + ", DateOfBirth= " + dateOfBirth + ", dateOfHire= " + dateOfHire + ", Salary= " + salary + ", Status= " + status + ", listOfCourses= " + courses + '}'; 
    }


}
