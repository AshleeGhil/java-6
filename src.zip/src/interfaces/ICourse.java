package interfaces;

import exceptionhandlers.InvalidDataException;

public interface ICourse {

    public void setCourseID(String p_courseID) throws InvalidDataException;
    public void setCourseName(String p_courseName);
    public void setClassroom(IClassroom p_classroom) throws InvalidDataException;

    public String getCourseID();
    public String getCourseName();
    public IClassroom getClassroom();

}
