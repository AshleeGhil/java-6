package interfaces;

// interface for Person

import exceptionhandlers.InvalidDataException;

public interface IPerson {

    public void setName (String p_name) throws InvalidDataException;

    public void setAddress (String p_address) throws InvalidDataException;

    public void setDateOfBirth (java.time.LocalDate p_dateOfBirth) throws InvalidDataException;

    public String getName ();
    public String getAddress ();
    public java.time.LocalDate  getDateOfBirth ();

}
