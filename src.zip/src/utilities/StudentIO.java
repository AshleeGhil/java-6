package utilities;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import datacontainers.StudentDC;
import datamodels.Student;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;

public class StudentIO {

    private StudentIO() {

    }

    public static void writeJSONFile (String fileLocation, StudentDC datacontainer) {
        PrintWriter jsonFile = null;

        try {
            jsonFile = new PrintWriter(fileLocation + "student.json");
            Gson gson = new GsonBuilder().create();
            gson.toJson(datacontainer.getListOfStudents(), jsonFile);
        } catch (Exception exp) {
            // TO-DO
        } finally {
            jsonFile.flush();
            jsonFile.close();
        }
    }

    public static ArrayList<Student> readJSONFile(String fileLocation) {

        ArrayList<Student> listOfStudents = new ArrayList<>();

        try {
            // Create input file
            BufferedReader jsonFile = new BufferedReader(new FileReader(fileLocation + "student.json"));

            // Create JSON object
            Gson gson = new GsonBuilder().create();

            // fromJson returns an array
            Student[] studentArray = gson.fromJson(jsonFile, Student[].class);

            // Convert to arraylist for the data model
            for (int i = 0; i < studentArray.length; i++) {
                listOfStudents.add(studentArray[i]);
            }
        } catch (Exception exp) {
            // TO-DO
        } finally {
            return listOfStudents;
        }
    }
}

